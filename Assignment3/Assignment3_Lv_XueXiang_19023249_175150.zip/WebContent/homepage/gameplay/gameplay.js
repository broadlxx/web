function Terran(){
	windows.locatiom.hash = "#Terran1";
}

function Orcs(){
	windows.locatiom.hash = "#Orcs1";
}
function Undead(){
	windows.locatiom.hash = "#Undead1";
}
function Night_elf(){
	windows.locatiom.hash = "#Night_elf1";
}