var count = localStorage.length;

function submited(){
	count++
	
	var firstname = document.getElementById("firstname").value;
	var lastname = document.getElementById("lastname").value;
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	var phone = document.getElementById("phone").value;
	
	var timestamp = Date.parse(new Date());
    var now = new Date(timestamp);
    var year=now.getFullYear();     
    var month=now.getMonth()+1;     
    var date=now.getDate();     
    var hour=now.getHours();     
    var minute=now.getMinutes();     
    var second=now.getSeconds();
//	document.getElementById("output").innerHTML = "firstname:"+firstname+" "+"lastname:"+lastname+" "+"email:"+email+" "+"password:"+password+" "+"phone:"+phone+" "+"\n";
//	window.localStorage.setItem("time",year+"-"+month+"-"+date+"   "+hour+":"+minute+":"+second)
	window.localStorage.setItem("test"+count,year+"-"+month+"-"+date+"   "+hour+":"+minute+":"+second+"  "+"firstname:"+firstname+" "+"lastname:"+lastname+" "+"email:"+email+" "+"password:"+password+" "+"phone:"+phone+" "+"\n")
//	list.add(window.localStorage.setItem("test",year+"-"+month+"-"+date+"   "+hour+":"+minute+":"+second+"  "+"firstname:"+firstname+" "+"lastname:"+lastname+" "+"email:"+email+" "+"password:"+password+" "+"phone:"+phone+" "+"\n"))
}

function outputinformation(){
	var output = document.getElementById("output");
	output.innerHTML = ""
	for(var i=0;i<localStorage.length;i++){
		var key = localStorage.key(i);
		output.innerHTML += localStorage.getItem(key)+"<br>";
	}
	
}

function clearall() {
	localStorage.clear()
}